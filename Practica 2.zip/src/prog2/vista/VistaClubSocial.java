/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package prog2.vista;

import java.util.Scanner;
import prog2.model.ClubSocial;

/**
 *
 * @author Marina
 */
public class VistaClubSocial {
    private ClubSocial club;
    private Scanner sc = new Scanner(System.in);
    
    public VistaClubSocial(ClubSocial club, Scanner sc) throws ExcepcioClub {
        club = new ClubSocial();
    }
    public void gestioClubSocial() throws ExcepcioClub{
        Scanner sc = new Scanner(System.in);
        gestioMenu(sc);
    }
    
    private static enum OpcionsMenu{
        M_Opcio_DonarAltaSoci,
        M_Opcio_MostrarSocis,
        M_Opcio_MostrarSocisVip,
        M_Opcio_MostrarSocisEstandard,
        M_Opcio_MostrarSocisJunior,
        M_Opcio_EliminarSoci,
        M_Opcio_VerificarSocis,
        M_Opcio_MostrarActivitats,
        M_Opcio_MostrarActivitatsSoci,
        M_Opcio_AfegirActivitat,
        M_Opcio_Factura,
        M_Opcio_ModificarNomSoci,
        M_Opcio_ModificarTipusAsseguranca,
        M_Opcio_GuardarDades,
        M_Opcio_RecuperarDades,
        M_Opcio_Sortir
    };
    
    private static enum OpcionsSoci{
        M_Opcio_SociVip,
        M_Opcio_SociEstandard,
        M_Opcio_SociJunior,
        M_Opcio_MenuAnterior
    };
    
    private static final String[] descMenu = {
        "Donar d’alta un nou soci",
        "Mostrar llista de socis",
        "Mostrar llista de socis vip",
        "Mostrar llista de socis estandard",
        "Mostrar llista de socis junior",
        "Eliminar soci",
        "Verificar socis",
        "Mostrar llista d’activitats",
        "Mostrar llista d’activitats realitzades per un soci",
        "Afegir activitat realitzada per un soci",
        "Mostrar total factura",
        "Modificar nom soci",
        "Modificar tipus assegurança soci estàndard",
        "Guardar dades",
        "Recuperar dades"
    };
    
    private static final String[] descSoci = {
        "Afegir soci VIP",
        "Afegir soci Estandard",
        "Afegir soci Junior",
        "Menu anterior"
    };
    
    
    public void gestioMenu(Scanner sc) throws ExcepcioClub{
        Menu<OpcionsMenu> menuClub = new Menu<>("Menu Club Social ",OpcionsMenu.values()); 
        menuClub.setDescripcions(descMenu);
        OpcionsMenu opcioMenu;
        
        do{
            menuClub.mostrarMenu();
            opcioMenu = menuClub.getOpcio(sc);
            
            switch(opcioMenu){
                case M_Opcio_DonarAltaSoci:
                    break;
                case M_Opcio_MostrarSocis:
                    System.out.println(club.mostrarSocisMenu("Tots"));
                    break;
                case M_Opcio_MostrarSocisVip:
                    System.out.println(club.mostrarSocisMenu("VIP"));
                    break;
                case M_Opcio_MostrarSocisEstandard:
                    System.out.println(club.mostrarSocisMenu("Estandard"));
                    break;
                case M_Opcio_MostrarSocisJunior:
                    System.out.println(club.mostrarSocisMenu("Junior"));
                    break;
                case M_Opcio_EliminarSoci:
                    System.out.println("Dni del soci que es vol eliminar?\n");
                    System.out.println(club.mostrarSocisMenu("Tots"));
                    String dni = sc.nextLine();
                    club.eliminarSociMenu(dni);
                    break;
                case M_Opcio_VerificarSocis:
                    club.verificarSocisMenu();
                    break;
                case M_Opcio_MostrarActivitats:
                    System.out.println(club.mostrarActivitats());
                    break;
                case M_Opcio_MostrarActivitatsSoci:
                    System.out.println("Dni del soci del qual es vol mostrar la llista d'activitats?\n");
                    System.out.println(club.mostrarSocisMenu("Tots"));
                    dni = sc.nextLine();
                    System.out.println(club.mostrarActivitatsSoci(dni));
                    break;
                case M_Opcio_AfegirActivitat:
                    System.out.println("Dni del soci al qual se li vol afegir una activitat?\n");
                    System.out.println(club.mostrarSocisMenu("Tots"));
                    dni = sc.nextLine();
                    System.out.println("Numero de l'activitat que se li vol afegir?\n");
                    int activitat = sc.nextInt();
                    club.afegirActivitatMenu(dni, activitat);                    
                    break;
                case M_Opcio_Factura:
                    System.out.println("Dni del soci del qual es vol consultar la factura?\n");
                    System.out.println(club.mostrarSocisMenu("Tots"));
                    dni = sc.nextLine();
                    System.out.println("El preu de la factura del soci es " + club.calcularFacturaMenu(dni) + "\n");
                    break;
                case M_Opcio_ModificarNomSoci:
                    System.out.println("Dni del soci al qual se li vol canviar el nom\n");
                    System.out.println(club.mostrarSocisMenu("Tots"));
                    dni = sc.nextLine();
                    System.out.println("Nou nom?\n");
                    String nom = sc.nextLine();
                    club.canviarNomSociMenu(dni, nom);
                    break;
                case M_Opcio_ModificarTipusAsseguranca:
                    System.out.println("Dni del soci al qual se li vol canviar l'assegurança\n");
                    System.out.println(club.mostrarSocisMenu("Tots"));
                    dni = sc.nextLine();
                    System.out.println("Nou tipus d'assegurança\n");
                    nom = sc.nextLine();
                    break;
                case M_Opcio_GuardarDades:
                    break;
                case M_Opcio_RecuperarDades:
                    break;
            }
        } while(opcioMenu != OpcionsMenu.M_Opcio_Sortir);
   }
}
