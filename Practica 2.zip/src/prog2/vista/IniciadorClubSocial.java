/*
 * Universitat de Barcelona
 * Programació 2
 * Curs 2022-2023
 */
package prog2.vista;


public class IniciadorClubSocial {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        VistaClubSocial vistaClub = new VistaClubSocial();
        
        vistaClub.gestioClub();
        
    }
    
}
