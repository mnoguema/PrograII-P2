/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package prog2.model;

import java.io.Serializable;
import java.util.Iterator;
import prog2.vista.ExcepcioClub;

/**
 *
 * @author Marina
 */
public class ClubSocial implements Serializable {
    private static final float quotaEstandard = 25;
    private static final float quotaVIP = 50;
    private static final float descompteVIP = 20;
    private LlistaActivitats llistaActivitats;
    private LlistaSocis llistaSocis;
    
    public ClubSocial(int capacitat) throws ExcepcioClub{
        llistaActivitats = new LlistaActivitats();
        llistaSocis = new LlistaSocis(capacitat);
        llistaActivitats.carregaLlistaActivitats("llistaActivitats.txt");
    }
    
    public ClubSocial() throws ExcepcioClub{
        llistaActivitats = new LlistaActivitats();
        llistaSocis = new LlistaSocis(100);
        llistaActivitats.carregaLlistaActivitats("llistaActivitats.txt");
    }
    
    public String mostrarSocisMenu(String tipus) throws ExcepcioClub {
        return llistaSocis.getSubllistaSocisByType(tipus).toString();
    }
    
    public void eliminarSociMenu(String dni) throws ExcepcioClub {
        llistaSocis.removeSoci(llistaSocis.getSoci(dni));
    }
    
    public void verificarSocisMenu() throws ExcepcioClub {
        llistaSocis.verificarSocis();
    }
    
    public String mostrarActivitats(){    
        return llistaActivitats.toString();
    }
    
    public String mostrarActivitatsSoci(String dni) throws ExcepcioClub {
        return llistaSocis.getSoci(dni).getActivitatsRealitzades().toString();
    }
    
    public void afegirActivitatMenu(String dni, int activitat) throws ExcepcioClub {
        llistaSocis.getSoci(dni).afegirActivitatRealitzada(llistaActivitats.getAt(activitat));
    }
    
    public float calcularFacturaMenu(String dni) throws ExcepcioClub {
        return llistaSocis.getSoci(dni).calcularFactura();
    }
    
    public void canviarNomSociMenu(String dni, String nom) throws ExcepcioClub {
        llistaSocis.getSoci(dni).setNom(nom);
    }
    
    /*public void canviarAsseguranca(String dni, String tipus, float preu) throws ExcepcioClub {
        if(llistaSocis.getSoci(dni).tipusSoci().equals("VIP")) {
            llistaSocis.getSoci(dni).setAsseguranca(tipus, preu);
        }
    }*/
    
    /*les classes de guardar-se i carregar-se com a objecte en un fitxer*/
    

}
